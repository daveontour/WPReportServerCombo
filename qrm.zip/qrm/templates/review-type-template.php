<?php
$type = "review";
include dirname(__FILE__).'/qrm-type-template.php';
